# `fixlib`
Resoto common library


## Table of contents

* [Overview](#overview)
* [Contact](#contact)
* [License](#license)


## Overview
This is the Resoto common library. Any functionality that is required by more than one of [our components](https://github.com/someengineering/fixinventory#component-list) will be put in here.

## Contact
If you have any questions feel free to [join our Discord](https://discord.gg/someengineering) or [open a GitHub issue](https://github.com/someengineering/fixinventory/issues/new).


## License
See [LICENSE](../LICENSE) for details.
