# fix-plugin-example-collector
Example Collector Plugin for Fix

## License
See [LICENSE](../../LICENSE) for details.
